# ¿Qué cocino hoy?

App web para decidir qué cocinar con lo que ya tenés en casa. Cargás tus ingredientes, o le sacás una foto a la heladera, y te sugiere recetas caseras ordenadas según lo que tenés. Las que usan ingredientes por vencerse aparecen primero.

Pensada para el celular: una mano libre, la otra con la cuchara.

## Funciones

- **Tu heladera:** cargá ingredientes escribiéndolos, con sugerencias mientras tipeás, o tocando atajos rápidos. Se pueden agregar varios a la vez separados por comas.
- **Foto de la heladera:** reconoce los ingredientes de una foto y los suma solos. Acepta fotos de la cámara o de la galería, incluidas las del iPhone.
- **Vence pronto:** tocá un ingrediente para marcarlo. Las recetas que lo usan suben en la lista.
- **Recetas ordenadas:** primero la mejor opción, después el resto. Cada una indica qué te falta.
- **Filtros:** recetas que podés hacer ya, recetas rápidas (hasta 25 min) y la opción de dar por hecho que tenés sal, aceite y pimienta.
- **Porciones:** las cantidades se recalculan según cuántas porciones quieras.
- **Timers:** los pasos que indican un tiempo traen un temporizador, con sonido y vibración al terminar.
- **Pantalla encendida:** mientras mirás una receta, el celular no se bloquea.
- **Lista del súper:** copiá con un toque lo que te falta, con cantidades.
- **Deshacer:** recuperá un ingrediente borrado o la heladera vaciada por error.
- **Modo oscuro** automático y animaciones que respetan la opción de reducir movimiento.

## Tecnología

- Un solo archivo HTML con CSS y JavaScript sin frameworks ni dependencias.
- Tipografías de Google Fonts: Geist e Instrument Serif.
- Los ingredientes y preferencias se guardan en el navegador (`localStorage`). No hay cuentas ni servidor.
- 20 recetas caseras argentinas incluidas en el código.

## Reconocimiento de fotos

La versión actual usa Claude para analizar la foto. Por eso esa función solo anda si la página se abre dentro de Claude con una cuenta iniciada. Fuera de Claude, la app funciona completa, pero los ingredientes se cargan a mano.

Para que la foto funcione en un hosting propio, hay que reemplazar esa parte por una llamada a una API de visión, como la API de Claude, a través de un servidor propio que guarde la clave. Las APIs cobran por uso.

## Cómo usarla

No necesita instalación ni compilación:

1. Cloná o descargá el repositorio.
2. Abrí `index.html` en el navegador.

### Publicarla con GitHub Pages

1. Subí `index.html` a la rama `main`.
2. En el repositorio, entrá a **Settings → Pages**.
3. En **Source**, elegí la rama `main` y la carpeta `/ (root)`.
4. En unos minutos la app queda en `https://<tu-usuario>.github.io/<nombre-del-repo>/`.

Desde el celular, abrí esa dirección y elegí **Agregar a pantalla de inicio** para tenerla como una app más.

## Agregar recetas

Las recetas están en el array `R` del script. Cada una tiene nombre (`n`), tiempo en minutos (`t`), ingredientes (`i`) y pasos (`s`):

```js
{n:"Omelette de queso", t:10, i:["huevo","queso","manteca","sal"], s:["Batí los huevos con sal.", "..."]}
```

Las cantidades van en el objeto `Q`: primero las porciones base y después la cantidad de cada ingrediente:

```js
"Omelette de queso": [1, {huevo:[3], queso:[60,"g"], manteca:[10,"g"]}]
```

Si un paso menciona un tiempo, como "cociná 15 min", el botón de timer aparece solo.

## Próximos pasos

- [ ] Instalable sin internet (manifest y service worker)
- [ ] Reconocimiento de fotos con API propia
- [ ] Más recetas y filtro vegetariano
- [ ] Lista del súper que junte varias recetas

## Licencia

MIT
